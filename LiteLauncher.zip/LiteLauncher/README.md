# LiteLauncher
Launcher Android leve e sem travamentos (Kotlin, 1 dependência).

Build automático: aba Actions > Build APK > Artifacts > LiteLauncher-apk.
