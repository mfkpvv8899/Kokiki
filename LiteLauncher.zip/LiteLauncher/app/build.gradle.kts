plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.lite.launcher"
    compileSdk = 34
    defaultConfig { applicationId = "com.lite.launcher"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    buildTypes { release { isMinifyEnabled = true; isShrinkResources = true
        proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt")) } }
}
dependencies { implementation("androidx.recyclerview:recyclerview:1.3.2") }
