package com.lite.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class Opt(val k: String, val t: String, val d: Any = 0, val a: Int = 0, val b: Int = 0,
          val ch: List<String> = emptyList(), val u: String = "")

val OPTS = listOf(
    Opt("#", "INTERFACE"),
    Opt("scale", "Tamanho da interface", 100, 80, 140, u = "%"),
    Opt("dim", "Escurecer o fundo", 15, 0, 80, u = "%"),
    Opt("hidesb", "Ocultar barra de status", false),
    Opt("anim", "Animação ao abrir apps", true),
    Opt("haptic", "Vibrar no toque longo", true),
    Opt("top", "Voltar ao topo ao tocar em Home", true),
    Opt("#", "ÍCONES"),
    Opt("cols", "Colunas", 4, 3, 6),
    Opt("icon", "Tamanho do ícone", 56, 32, 96, u = " dp"),
    Opt("shape", "Formato do ícone", "Squircle", ch = listOf("Squircle", "Arredondado", "Círculo", "Quadrado", "Original")),
    Opt("labels", "Mostrar nomes", true),
    Opt("tsize", "Tamanho do texto", 12, 9, 16, u = " sp"),
    Opt("tcolor", "Cor do texto", "Branco", ch = listOf("Branco", "Preto", "Cinza", "Amarelo")),
    Opt("shadow", "Sombra no texto", true),
    Opt("vgap", "Espaço vertical", 8, 0, 24, u = " dp"),
    Opt("side", "Margem lateral", 8, 0, 32, u = " dp"),
    Opt("sort", "Ordem dos apps", "A–Z", ch = listOf("A–Z", "Z–A", "Mais recentes", "Mais antigos")),
    Opt("#", "DOCK"),
    Opt("dock", "Mostrar dock", true),
    Opt("dicon", "Tamanho dos ícones da dock", 56, 36, 72, u = " dp"),
    Opt("dalpha", "Opacidade da dock", 40, 0, 100, u = "%"),
    Opt("dround", "Cantos da dock", 24, 0, 40, u = " dp"),
    Opt("dtheme", "Cor da dock", "Escuro", ch = listOf("Escuro", "Claro", "Transparente")),
    Opt("dlabels", "Nomes na dock", false),
    Opt("#", "BUSCA"),
    Opt("search", "Mostrar barra Buscar", true),
    Opt("kbd", "Abrir teclado ao buscar", true),
    Opt("auto", "Abrir app se só houver 1 resultado", false),
    Opt("#", "AÇÕES"),
    Opt("!wall", "Trocar papel de parede"),
    Opt("!home", "Definir como launcher padrão"),
    Opt("!hid", "Mostrar apps ocultos"),
    Opt("!reset", "Restaurar padrões"))

class SettingsActivity : Activity() {
    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun tv(t: String, sz: Float = 16f) = TextView(this).apply {
        text = t; textSize = sz; setPadding(dp(20f), dp(12f), dp(20f), dp(12f)) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s); U.init(this); title = "Configurações"
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        OPTS.forEach { box.addView(row(it)) }
        setContentView(ScrollView(this).apply { addView(box) })
    }

    private fun row(o: Opt): View = when {
        o.k == "#" -> tv(o.t, 13f).apply { setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF1A73E8.toInt()); setPadding(dp(20f), dp(20f), dp(20f), dp(4f)) }
        o.k[0] == '!' -> tv(o.t).apply { setOnClickListener { act(o.k) } }
        o.d is Boolean -> Switch(this).apply { text = o.t; textSize = 16f
            setPadding(dp(20f), dp(12f), dp(20f), dp(12f)); isChecked = U.b(o.k, o.d)
            setOnCheckedChangeListener { _, c -> U.sp.edit().putBoolean(o.k, c).apply() } }
        o.ch.isNotEmpty() -> tv("").apply {
            fun up() { text = "${o.t}: ${U.s(o.k, o.d as String)}" }
            up()
            setOnClickListener { AlertDialog.Builder(this@SettingsActivity).setTitle(o.t)
                .setItems(o.ch.toTypedArray()) { _, i -> U.sp.edit().putString(o.k, o.ch[i]).apply(); up() }.show() } }
        else -> LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val l = tv(""); val sb = SeekBar(this@SettingsActivity)
            fun up(v: Int) { l.text = "${o.t}: $v${o.u}" }
            val cur = U.i(o.k, o.d as Int)
            up(cur); sb.max = o.b - o.a; sb.progress = cur - o.a
            sb.setPadding(dp(20f), 0, dp(20f), dp(8f))
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    U.sp.edit().putInt(o.k, p + o.a).apply(); up(p + o.a) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {} })
            addView(l); addView(sb) }
    }

    private fun act(k: String) {
        when (k) {
            "!wall" -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Papel de parede"))
            "!home" -> startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            "!hid" -> {
                val h = (U.sp.getStringSet("hidden", emptySet()) ?: emptySet()).toList()
                if (h.isEmpty()) toast("Nenhum app oculto") else {
                    val names = h.map { x -> val p = ComponentName.unflattenFromString(x)!!.packageName
                        try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString() } catch (e: Exception) { p } }
                    AlertDialog.Builder(this).setTitle("Mostrar app").setItems(names.toTypedArray()) { _, i ->
                        U.sp.edit().putStringSet("hidden", h.toSet() - h[i]).apply(); toast("Reexibido") }.show() } }
            "!reset" -> { U.sp.edit().clear().apply(); recreate() }
        }
    }
}
